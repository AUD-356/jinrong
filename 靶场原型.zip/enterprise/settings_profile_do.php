<?php
session_start();
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

if (!isset($_SESSION['enterprise_id'])) {
    redirect('login.php');
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('settings.php');
}

$enterpriseId = $_SESSION['enterprise_id'];
$companyName = sanitize($_POST['company_name'] ?? '');
$legalPerson = sanitize($_POST['legal_person'] ?? '');
$email = sanitize($_POST['email'] ?? '');
$address = sanitize($_POST['address'] ?? '');

if (empty($companyName)) {
    $_SESSION['error'] = '企业名称不能为空';
    redirect('settings.php');
}

if (!empty($email) && !validateEmail($email)) {
    $_SESSION['error'] = '请输入正确的邮箱地址';
    redirect('settings.php');
}

dbExecute("UPDATE enterprises SET company_name = ?, legal_person = ?, email = ?, address = ?, updated_at = NOW() WHERE id = ?", 
    [$companyName, $legalPerson, $email, $address, $enterpriseId]);

$_SESSION['company_name'] = $companyName;
$_SESSION['success'] = '企业信息修改成功';

redirect('settings.php');
